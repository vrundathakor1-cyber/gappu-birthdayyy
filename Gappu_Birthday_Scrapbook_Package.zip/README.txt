Gappu Birthday Scrapbook Website

Open index.html in a browser. The four photos are embedded in the HTML, so no separate image folder is needed.

To share with a friend by QR code, first publish this page online (for example with GitHub Pages). Then create a QR code from the live website URL. A QR code made from a local file path will not work on your friend's phone.
